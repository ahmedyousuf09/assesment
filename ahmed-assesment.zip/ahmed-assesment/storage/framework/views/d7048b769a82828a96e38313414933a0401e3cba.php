<?php
/**
 * Created by PhpStorm.
 * User: Muhammad Ahmed
 * Date: 12/6/2018
 * Time: 1:15 PM
 */
?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="/home">Dashboard</a>
            </li>

        </ol>

        <!-- Page Content -->
        <h1>Welcome To Assesment Test</h1>
        <hr>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.theme', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>