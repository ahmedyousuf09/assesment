<?php
/**
 * Created by PhpStorm.
 * User: Muhammad Ahmed
 * Date: 12/6/2018
 * Time: 1:15 PM
 */
?>
@extends('layouts.theme')

@section('content')
    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="/home">Dashboard</a>
            </li>

        </ol>

        <!-- Page Content -->
        <h1>Welcome To Assesment Test</h1>
        <hr>
    </div>

@endsection

