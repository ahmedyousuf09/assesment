<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;
use App\Countries;


class CiviliansTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $countries = Countries::all();;
        foreach ($countries as $country){
            $faker = Faker::create();
            foreach (range(1,8) as $index) {
                DB::table('civilians')->insert([
                    'first_name' => $faker->name,
                    'last_name' => $faker->name,
                    'company_id' => $country['id'],
                    'email' => $faker->email,
                    'phone' => $faker->phoneNumber,
                ]);
            }
        }
    }
}
