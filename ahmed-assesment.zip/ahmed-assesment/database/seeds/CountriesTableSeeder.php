<?php

use Illuminate\Database\Seeder;

class CountriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('countries')->insert([
            [
                'name' => 'Country-A',
                'email' => 'Country-A@gmail.com',
                'logo' => '',
                'website' => 'Country-A.com'
            ],
            [
                'name' => 'Country-B',
                'email' => 'Country-B@gmail.com',
                'logo' => '',
                'website' => 'Country-B.com'
            ],
            [
                'name' => 'Country-C',
                'email' => 'Country-C@gmail.com',
                'logo' => '',
                'website' => 'Country-C.com'
            ],
            [
                'name' => 'Country-D',
                'email' => 'Country-D@gmail.com',
                'logo' => '',
                'website' => 'Country-D.com'
            ],
            [
                'name' => 'Country-E',
                'email' => 'Country-E@gmail.com',
                'logo' => '',
                'website' => 'Country-E.com'
            ],
            [
                'name' => 'Country-F',
                'email' => 'Country-F@gmail.com',
                'logo' => '',
                'website' => 'Country-F.com'
            ],
            [
                'name' => 'Country-G',
                'email' => 'Country-G@gmail.com',
                'logo' => '',
                'website' => 'Country-G.com'
            ],
            [
                'name' => 'Country-H',
                'email' => 'Country-H@gmail.com',
                'logo' => '',
                'website' => 'Country-H.com'
            ],
            [
                'name' => 'Country-I',
                'email' => 'Country-I@gmail.com',
                'logo' => '',
                'website' => 'Country-I.com'
            ],
            [
                'name' => 'Country-J',
                'email' => 'Country-J@gmail.com',
                'logo' => '',
                'website' => 'Country-J.com'
            ],
            [
                'name' => 'Country-K',
                'email' => 'Country-K@gmail.com',
                'logo' => '',
                'website' => 'Country-K.com'
            ],
            [
                'name' => 'Country-L',
                'email' => 'Country-L@gmail.com',
                'logo' => '',
                'website' => 'Country-L.com'
            ],
            [
                'name' => 'Country-M',
                'email' => 'Country-M@gmail.com',
                'logo' => '',
                'website' => 'Country-M.com'
            ],
            [
                'name' => 'Country-N',
                'email' => 'Country-N@gmail.com',
                'logo' => '',
                'website' => 'Country-N.com'
            ],
            [
                'name' => 'Country-O',
                'email' => 'Country-O@gmail.com',
                'logo' => '',
                'website' => 'Country-O.com'
            ],
            [
                'name' => 'Country-P',
                'email' => 'Country-P@gmail.com',
                'logo' => '',
                'website' => 'Country-P.com'
            ],
            [
                'name' => 'Country_Q',
                'email' => 'Country_Q@gmail.com',
                'logo' => '',
                'website' => 'Country_Q.com'
            ],
            [
                'name' => 'Country_R',
                'email' => 'Country_R@gmail.com',
                'logo' => '',
                'website' => 'Country_R.com'
            ],
            [
                'name' => 'Country_S',
                'email' => 'Country_S@gmail.com',
                'logo' => '',
                'website' => 'Country_S.com'
            ],
            [
                'name' => 'Country_T',
                'email' => 'Country_T@gmail.com',
                'logo' => '',
                'website' => 'Country_T.com'
            ],
            [
                'name' => 'Country_U',
                'email' => 'Country_U@gmail.com',
                'logo' => '',
                'website' => 'Country_U.com'
            ],
            [
                'name' => 'Country_V',
                'email' => 'Country_V@gmail.com',
                'logo' => '',
                'website' => 'Country_V.com'
            ],
            [
                'name' => 'Country_W',
                'email' => 'Country_W@gmail.com',
                'logo' => '',
                'website' => 'Country_W.com'
            ],
            [
                'name' => 'Country_X',
                'email' => 'Country_X@gmail.com',
                'logo' => '',
                'website' => 'Country_X.com'
            ],
            [
                'name' => 'Compan_Y',
                'email' => 'Compan_Y@gmail.com',
                'logo' => '',
                'website' => 'Compan_Y.com'
            ],
            [
                'name' => 'Country_Z',
                'email' => 'Country_Z@gmail.com',
                'logo' => '',
                'website' => 'Country_Z.com'
            ]
        ]);
    }
}
